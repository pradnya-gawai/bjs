import React from 'react'
import ProductCrad from '../components/ProductCrad'

export default function ProductList({data,setCartItem,cartItem}) {
    
    return (
        <div>
            {data.map((data) => (
                <ProductCrad data={data} setCartItem={setCartItem} cartItem={cartItem} />
            )

            )}

        </div>
    )
}
