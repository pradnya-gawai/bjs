import React, { useState } from 'react'

export default function Cart({cartItem}) {
    console.log(cartItem,"cartItem")

  return (
    <div>
        <h3> Total Item {cartItem?.length}</h3>
    </div>
  )
}
