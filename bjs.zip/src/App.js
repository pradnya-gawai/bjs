import logo from './logo.svg';
import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import { productList } from "./redux/productSlice"
import { useEffect, useState } from 'react';
import ProductCrad from './components/ProductCrad';
import NavBar from './components/NavBar';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import ProductList from './pages/ProductList';
import Cart from './pages/Cart';

function App() {
  // const dispatch = useDispatch()
  const [data, setData] = useState([])
  const[cartItem,setCartItem]=useState()

  // const product = useSelector((state) => state?.products)
  const fetchData = () => {
    fetch('https://fakestoreapi.com/products')
      .then(res => res.json())
      .then(json => setData(json))

  }
  useEffect(() => {
    fetchData()
  }, [])
  console.log(data, "data")

  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="home" element={<Home />} />
        <Route path="/products" element={<ProductList data={data} setCartItem={setCartItem} cartItem={cartItem} />} />
        <Route path="/cart" element={<Cart  cartItem={cartItem}/>} />

      </Routes>

    </BrowserRouter>

  )
}

export default App;
