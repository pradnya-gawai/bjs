import { createSlice } from '@reduxjs/toolkit'


export const productSlice = createSlice({
  name: 'product',
  initialState:{
    productList:[]
  },
  reducers: {
    productList: (state,action) => {
      state =action
    },
   
  },
})

// Action creators are generated for each case reducer function
export const { productList } = productSlice.actions

export default productSlice.reducer