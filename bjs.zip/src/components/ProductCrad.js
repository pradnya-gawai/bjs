import React from 'react'
import { useLocation } from 'react-router-dom';

export default function ProductCrad({ data, setCartItem, cartItem }) {
    let location = useLocation();
    console.log(location)

    return (
        <div className='d-flex flex-direction-row'>
            <div className="row mt-3">
                <div className="col-sm-6">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">{data?.title}</h5>
                            <h2> {data?.category}</h2>
                            <p className="card-text">{data?.description}</p>
                            <a href="#" className="btn btn-primary" onClick={() => {
                                setCartItem(data)

                            }}>Add</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}
